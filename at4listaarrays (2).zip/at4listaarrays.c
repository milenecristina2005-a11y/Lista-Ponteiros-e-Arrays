#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char palavra[100];
    printf("Digite uma palavra: ");
    scanf("%s", palavra);
    
    printf("A palavra escolhida foi: %s.", palavra);
    
    int tam = strlen(palavra);
    printf("%d", tam);
    
}