#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char *dados;
    int tamanho_alocado;
    int topo;
} Pilha;

Pilha* criar(int capacidade) {
    Pilha *p = (Pilha*) malloc(sizeof(Pilha));
    p->dados = (char*) malloc(capacidade * sizeof(char));
    p->tamanho_alocado = capacidade;
    p->topo = 0;
    return p;
}

int pilha_vazia(Pilha *p) {
    return (p->topo == 0);
}

void push(Pilha *p, char valor) {
    if (p->topo == p->tamanho_alocado) {
        p->tamanho_alocado *= 2;
        p->dados = (char*) realloc(p->dados, p->tamanho_alocado * sizeof(char));
    }
    p->dados[p->topo] = valor;
    p->topo++;
}

char pop(Pilha *p) {
    if (pilha_vazia(p)) {
        printf("Pilha vazia\n");
        exit(1);
    }
    p->topo--;
    return p->dados[p->topo];
}

void liberar(Pilha *p) {
    free(p->dados);
    free(p);
}

// Balanceamento
void verificar_balanceamento(char *expr) {
    Pilha *p = criar(strlen(expr));
    int erro = 0;
    
    for (int i = 0; expr[i] != '\0'; i++) {
        char c = expr[i];
        
        if (c == '(' || c == '[' || c == '{') {
            push(p, c);
        } 
        else if (c == ')' || c == ']' || c == '}') {
            if (pilha_vazia(p)) {
                printf("Expressão: %s -> Não balanceada: fechamento sem abertura (pilha vazia)\n", expr);
                erro = 1;
                break;
            }
            
            char topo = pop(p);
            if ((c == ')' && topo != '(') ||
                (c == ']' && topo != '[') ||
                (c == '}' && topo != '{')) {
                printf("Expressão: %s -> Não balanceada: fechamento na ordem errada\n", expr);
                erro = 1;
                break;
            }
        }
    }
    
    if (!erro) {
        if (pilha_vazia(p)) {
            printf("Expressão: %s -> Balanceada\n", expr);
        } else {
            printf("Expressão: %s -> Não balanceada: sobrou uma abertura\n", expr);
        }
    }
    
    liberar(p);
}

int main() {
    // Testes
    char *testes[] = {
        "{[()]}",
        "if (a[i] > 0) { x = (a + b) * 2; }",
        "([)]",
        "((3 + 2)",
        ")("
    };
    
    int total_testes = 5;
    for (int i = 0; i < total_testes; i++) {
        verificar_balanceamento(testes[i]);
    }
    
    return 0;
}