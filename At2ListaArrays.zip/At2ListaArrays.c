#include <stdio.h>

int main()
{
    int x, y, r;
    printf("Digite o valor de x: ");
    scanf("%d", &x);
    printf("Digite o valor de y: ");
    scanf("%d", &y);
    
    if (y > x) {
        r = x;
        x = y;
        y = r;
        printf("O valor de x é: %d, O valor de y é: %d", x , y);
    } else {
        printf("O valor de x é: %d, O valor de y é: %d", x , y);
    }

    return 0;
}