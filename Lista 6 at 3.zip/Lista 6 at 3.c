#include <stdio.h>
#include <stdlib.h>


typedef struct No {
    int valor;
    struct No *proximo;
} No;

typedef struct {
    No *frente;
    No *fundo;
    int tamanho;
} Fila;

Fila* criar_fila() {
    Fila *f = (Fila*) malloc(sizeof(Fila));
    f->frente = NULL;
    f->fundo = NULL;
    f->tamanho = 0;
    return f;
}

int fila_vazia(Fila *f) {
    return (f->tamanho == 0);
}

void entra(Fila *f, int valor) {
    No *novo = (No*) malloc(sizeof(No));
    if (novo == NULL) {
        printf("Sem memória\n");
        exit(1);
    }
    novo->valor = valor;
    novo->proximo = NULL;
    if (fila_vazia(f)) {
        f->frente = novo;
    } else {
        f->fundo->proximo = novo;
    }
    f->fundo = novo;
    f->tamanho++;
}

int sai(Fila *f) {
    if (fila_vazia(f)) {
        printf("Fila vazia\n");
        exit(1);
    }
    No *removido = f->frente;
    int valor = removido->valor;
    f->frente = removido->proximo;
    if (f->frente == NULL) {
        f->fundo = NULL;
    }
    free(removido);
    f->tamanho--;
    return valor;
}

void liberar_fila(Fila *f) {
    while (!fila_vazia(f)) {
        sai(f);
    }
    free(f);
}

int main() {
    int n, k;
    
    printf("Digite o número de crianças (N): ");
    if (scanf("%d", &n) != 1) return 1;
    
    printf("Quantas batatas quentes? ");
    if (scanf("%d", &k) != 1) return 1;
    
    Fila *f = criar_fila();
    
    // Enfileirar
    for (int i = 1; i <= n; i++) {
        entra(f, i);
    }
    
    printf("Ordem de eliminação: ");
    int primeiro = 1;
    
    while (f->tamanho > 1) {
        // Batata passando
        for (int i = 0; i < k - 1; i++) {
            int crianca = sai(f);
            entra(f, crianca);
        }
        
        // Queimou
        int queimou = sai(f);
        if (!primeiro) {
            printf(", ");
        }
        printf("%d", queimou);
        primeiro = 0;
    }
    
    int vencedora = sai(f);
    printf("\nVencedora: criança %d\n", vencedora);
    
    liberar_fila(f);
    
    return 0;
}